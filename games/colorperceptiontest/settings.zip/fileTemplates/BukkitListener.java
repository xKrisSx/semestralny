#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class ${NAME} implements Listener {

    @EventHandler
    public void on( e) {
        //e.setCancelled(true)
    }
}
