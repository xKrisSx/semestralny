#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.time.OffsetDateTime;
import java.util.Random;

public class ${NAME} extends ListenerAdapter {

    @Override
    public void onGuildMessageReceived(GuildMessageReceivedEvent event) {
        Message message = event.getMessage();
        String c = message.getContentRaw();
        Guild guild = event.getGuild();
        MessageChannel channel = message.getChannel();
        Member self = guild.getSelfMember();
        OffsetDateTime t = event.getMessage().getTimeCreated();
        Random random = new Random();
        String[] args = c.split(" ");

        if (event.getAuthor().isBot()) {
            return;
        }
        
        if (args[0].equalsIgnoreCase("!")) {
            //
        }
    }
}